# Snappy.Sharp

An implementation of Google's Snappy compression algorithm in C#.

This is still a work in progress, especially the streaming stuff. 

The current status is that I think the compression and expansion algorithms work right. The streaming stuff has only just been started and shouldn't even be used.

