﻿using Xunit;

namespace Snappy.Sharp.Test
{
    public class SnappyDecompressionTests
    {
        [Fact]
        public void decompression_read_uncompressed_length_gives_back_length()
        {
        }

        [Fact]
        public void decompression_read_uncompressed_length_gives_back_count_of_bytes_making_up_length()
        {
        }

        [Fact]
        public void decompression_read_literal_outputs_literal()
        {

        }

        [Fact]
        public void decompression_read_copy_seeks_and_copies()
        {

        }

        [Fact]
        public void decompression_read_multiple_copy_repeats_the_literal()
        {
            
        }
    }
}
